package data.campaign.econ.industries;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.SpecialItemSpecAPI;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.econ.impl.NanoforgeInstallableItemPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommandUtils;
import org.lazywizard.console.Console;
import org.lazywizard.console.commands.AddSpecial;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;


public class Nanoforge_foundry extends BaseIndustry{
	
	public boolean canBeDisrupted() { return false; }

	

	
	public CargoAPI generateCargoForGatheringPoint(Random random) {
	    if (!isFunctional())
	    {
	      return null;
	    }
	    	    
	    CargoAPI result = Global.getFactory().createCargo(true);
	    result.clear();
	    float roll = random.nextFloat() * 100.0F;
	    
	    if (this.aiCoreId == null) {
	      
	      if (roll > 70.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null), 1);
	      }
	      else if (roll > 40.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.DECAYED_NANOFORGE, null), 1);
	      }
	    
	    } else if (this.aiCoreId.equals("alpha_core")) {
	      
	      if (roll > 70.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.PRISTINE_NANOFORGE, null), 1);
	      }
	      else if (roll > 40.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null), 1);
	      }
	      else if (roll > 10.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.DECAYED_NANOFORGE, null), 1);
	      }
	    
	    } else if (this.aiCoreId.equals("beta_core")) {
	      
	      if (roll > 80.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.PRISTINE_NANOFORGE, null), 1);
	      }
	      else if (roll > 50.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null), 1);
	      }
	      else if (roll > 20.0F)
	      {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.DECAYED_NANOFORGE, null), 1);
	      }
	    
	    } else if (this.aiCoreId.equals("gamma_core")) {
	      
	      if (roll > 90.0F) {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.PRISTINE_NANOFORGE, null), 1);
	      }
	      else if (roll > 60.0F) {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.CORRUPTED_NANOFORGE, null), 1);
	      }
	      else if (roll > 30.0F) {
	    	  result.addItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(Items.DECAYED_NANOFORGE, null), 1);
	      } 
	    } 
	    
	    return result;
	  }
	
	@Override
	public void apply() {
		 apply(true);
		 
		 int size = this.market.getSize();
		 demand("metals", size + 2);
		 demand("rare_metals", size + 2);
		 demand("supplies", size + 2);
		 demand("drugs", size + 1);
		 
	}
	
	public void startBuilding() { super.startBuilding(); }
	
	public boolean showWhenUnavailable() { return false; }

	protected void buildingFinished() {
		    super.buildingFinished();
		    
		    this.market.addTag("NANOFORGE_FOUNDRY_SHOW_TOOLTIP");
		  }
	 
	public boolean isAvailableToBuild() {
	    if (!this.market.isPlayerOwned())
	    {
	      return false;
	    }
	    
	    return true;
	  }

	protected void addRightAfterDescriptionSection(TooltipMakerAPI tooltip, Industry.IndustryTooltipMode mode) {
	    if (isBuilding() || !this.market.hasTag("NANOFORGE_FOUNDRY_SHOW_TOOLTIP")) {
	      return;
	    }
	    
	    float opad = 10.0F;
	    Color highlight = Misc.getHighlightColor();
	    Color bad = Misc.getNegativeHighlightColor();
	    
	    if (this.aiCoreId == null && isFunctional()) {
	      
	      tooltip.addPara("Current chances to produce an Nanoforge at the end of the month:\nCorrupted Nanoforge: %s\nDecayed Nanoforge: %s\nNothing: %s", opad, highlight, new String[] { "30%", "30%", "40%" });
	    }
	    else if (this.aiCoreId.equals("gamma_core") && isFunctional()) {
	      
	      tooltip.addPara("Current chances to produce an Nanoforge at the end of the month:\nPristine Nanoforge: %s\nCorrupted Nanoforge: %s\nDecayed Nanoforge: %s\nNothing: %s", opad, highlight, new String[] { "10%", "30%", "30%", "30%" });
	    }
	    else if (this.aiCoreId.equals("beta_core") && isFunctional()) {
	      
	      tooltip.addPara("Current chances to produce an Nanoforge at the end of the month:\nPristine Nanoforge: %s\nCorrupted Nanoforge: %s\nDecayed Nanoforge: %s\nNothing: %s", opad, highlight, new String[] { "20%", "30%", "30%", "20%" });
	    }
	    else if (this.aiCoreId.equals("alpha_core") && isFunctional()) {
	      
	      tooltip.addPara("Current chances to produce an Nanoforge at the end of the month:\nPristine Nanoforge: %s\nCorrupted Nanoforge: %s\nDecayed Nanoforge" + ": %s\nNothing: %s", opad, highlight, new String[] { "30%", "30%", "30%", "10%" });
	    } 
	  }

	public void notifyBeingRemoved(MarketAPI.MarketInteractionMode mode, boolean forUpgrade) {
	    super.notifyBeingRemoved(mode, forUpgrade);
	    
	    this.market.removeTag("NANOFORGE_FOUNDRY_SHOW_TOOLTIP");
	  }
}
