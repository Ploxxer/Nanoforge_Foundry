package data.campaign.econ;

public class Nanoforge_foundry_IDs {
	public static class Nanoforge_foundry_Industry_IDs {
	    public static final String NANOFORGE_FOUNDRY = "NANOFORGE_FOUNDRY";
	  }
}
