package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;

public class Nanoforge_foundry_plugin extends BaseModPlugin {
	  public void afterGameSave() {}
	  
	  public void onNewGame() {}
	}
